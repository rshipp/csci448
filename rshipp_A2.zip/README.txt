* Your Name / email
  Ryan Shipp / rshipp@mines.edu

* Assignment Number / Project Title
  Assignment 2 / Global Thermonuclear War

* A brief, high level description of what the program is / does
  Tic Tac Toe game

* A usage section, explaining how to run the program, which keys perform which actions, etc.
  Click the buttons

* Instructions on compiling your code
  Build in Android Studio

* Notes about bugs, implementation details, etc. if necessary
