* Your Name / email
  Ryan Shipp / rshipp@mines.edu

* Assignment Number / Project Title
  Assignment 3 / Criminal Intent

* A brief, high level description of what the program is / does
  List, view, create, delete, and edit Crimes

* A usage section, explaining how to run the program, which keys perform which actions, etc.
  Click the buttons

* Instructions on compiling your code
  Build in Android Studio

* Notes about bugs, implementation details, etc. if necessary
