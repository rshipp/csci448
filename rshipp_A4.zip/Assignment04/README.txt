* Your Name / email
  Ryan Shipp / rshipp@mines.edu

* Assignment Number / Project Title
  Assignment 4 / Sensor and Sensorability

* A brief, high level description of what the program is / does
  Breakout game using accelerometer and light level sensors

* A usage section, explaining how to run the program, which keys perform which actions, etc.
  Tilt phone to move the paddle
  Color scheme changes in the dark (light level < 10)
  Tap to restart after winning or losing the game

* Instructions on compiling your code
  Build in Android Studio

* Notes about bugs, implementation details, etc. if necessary
