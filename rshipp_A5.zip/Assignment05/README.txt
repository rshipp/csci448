* Your Name / email
  Ryan Shipp / rshipp@mines.edu

* Assignment Number / Project Title
  Assignment 5 / MapIt

* A brief, high level description of what the program is / does
  Map check-in app with GPS and local database

* A usage section, explaining how to run the program, which keys perform which actions, etc.
  MapView works, nothing else done

* Instructions on compiling your code
  Build in Android Studio

* Notes about bugs, implementation details, etc. if necessary
